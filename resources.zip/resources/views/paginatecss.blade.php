<style>
    .paginate_button {
        border-color: #0d6efd;
        color: #ffffff;
        padding: 10px 15px;
        border-radius: 5px;
        background-color: #969696;


    }

    .paginate_button.current.active {
        background-color: #0d6efd;
        color: #ffffff;
    }

    .paginate_button.disabled {
        border-color: #dedede;
        color: #ffffff;
    }
</style>